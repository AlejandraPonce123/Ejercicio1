import {NavigationContainer} from '@react-navigation/native';
import {createNativeStackNavigator} from '@react-navigation/native-stack';
import {HomeScreen} from './components/HomeScreen';
import {VideoCamera} from './components/videoCamera';
import {PhotoCamera} from './components/photoCamera'

const Stack = createNativeStackNavigator();

export default function App() {
  return (
    <NavigationContainer>
      <Stack.Navigator initialRouteName='Multimedia' screenOptions={{
        headerStyle:{
          backgroundColor: 'orange'
        },
        headerTitleStyle:{
          fontWeight:'bold',       
          color:'white'
        },
        headerTitleAlign:"center"
      }}>
        <Stack.Screen
          name="Multimedia"
          component={HomeScreen}
          options = {{headerLeft: null}}
          />
          <Stack.Screen
          name="PhotoCamera"
          component={PhotoCamera}
          />
          <Stack.Screen
          name="VideoCamera"
          component={VideoCamera}
          />
      </Stack.Navigator>
    </NavigationContainer>
  );
}
