import { Text, View, StyleSheet, TouchableOpacity } from 'react-native';
import Icon from "react-native-vector-icons/Ionicons";

var color = 'orange';

export function BarButton({ label = 'none', icon= 'film', state='default', onPress}) {

  if (state == 'default'){
    return (
      <TouchableOpacity onPress={onPress} style={styles.touchable}>
        <View style={styles.button_default}>
          <Icon name={icon} size={30} color="white" />
          <Text style={styles.text}>{label}</Text>
        </View>
    </TouchableOpacity>
  );
  }
  else {
    return (
    <View style={styles.button_selected}>
      <Icon name={icon} size={30} color="white" />
      <Text style={styles.text}>{label}</Text>
    </View>
    );
  }
}

const styles = StyleSheet.create({
  button_default: {
    flex:1,
    flexDirection: 'column',
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: 'orange'
  },
  button_selected: {
    flex:1,
    flexDirection: 'column',
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: 'darkorange'
  },
  text: {
    fontSize: 16,
    fontWeight: 'bold',
    color: 'white'
  },
  touchable:{flex:1}
});
