import React, { useState, useEffect, useRef } from 'react';
import { Text, SafeAreaView, StyleSheet, View } from 'react-native';
import {  BarButton } from './barButton';
import { MediaButton } from './MediaButton';
import { Camera, CameraType } from 'expo-camera';
import * as MediaLibrary from 'expo-media-library';


export function HomeScreen({ navigation }){

  return(
    <>
      <View style={styles.content}>
        <MediaButton label="Fotografía" icon='camera' onPress={()=> navigation.navigate('PhotoCamera')}/>
        <MediaButton label="Video" icon='videocam' onPress={()=> navigation.navigate('VideoCamera')}/>
      </View>
      <View style={styles.bar}>
        <BarButton label="Multimedia" icon="film" state="selected"/>
        <BarButton label="Lista de archivos" icon="file-tray-full" onPress={()=> navigation.navigate('Lista de Archivos')}/>
      </View>
    </>
  );
}

const styles = StyleSheet.create({
  bar: {
    backgroundColor: 'orange',
    flexDirection: 'row',
    alignItems: 'stretch',
    justifyContent: 'center',
    padding:0,
    height: 80
  },
  content:{
    flex:1,
    backgroundColor:"white",
    flexDirection: 'row',
    paddingVertical: 50
  }
});