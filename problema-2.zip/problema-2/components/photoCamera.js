import React, { useState, useRef, useEffect } from 'react';
import { Text, View, StyleSheet, Image, TouchableOpacity, FlatList, TextInput, Alert } from 'react-native';
import { Camera, CameraType } from 'expo-camera';
import * as MediaLibrary from 'expo-media-library';
import * as Location from 'expo-location';

export function PhotoCamera() {
  const [hasCameraPermission, setHasCameraPermission] = useState(null);
  const [images, setImages] = useState([]);
  const [type, setType] = useState(CameraType.back);
  const [flash, setFlash] = useState(Camera.Constants.FlashMode.off);
  const [annotation, setAnnotation] = useState('');
  const [currentImage, setCurrentImage] = useState(null);
  const [location, setLocation] = useState(null);
  const cameraRef = useRef(null);

  useEffect(() => {
    const setupPermissions = async () => {
      const cameraStatus = await Camera.requestCameraPermissionsAsync();
      const mediaStatus = await MediaLibrary.requestPermissionsAsync();
      const locationStatus = await Location.requestForegroundPermissionsAsync();

      setHasCameraPermission(cameraStatus.status === 'granted' && mediaStatus.status === 'granted');
      
      if (locationStatus.status === 'granted') {
        const location = await Location.getCurrentPositionAsync({});
        const reverseGeocode = await Location.reverseGeocodeAsync(location.coords);
        if (reverseGeocode.length > 0) {
          const city = reverseGeocode[0].city || reverseGeocode[0].region || 'Ubicación desconocida';
          setLocation(city);
        } else {
          setLocation('Ubicación desconocida');
        }
      }
    };

    setupPermissions();
  }, []);

  const takePicture = async () => {
    if (cameraRef.current) {
      try {
        const data = await cameraRef.current.takePictureAsync();
        setCurrentImage(data.uri);
      } catch (error) {
        console.log(error);
      }
    }
  };

  const savePicture = async (uri) => {
    if (uri && location) {
      try {
        const asset = await MediaLibrary.createAssetAsync(uri);

        const metadata = {
          uri: asset.uri,
          annotation,
          location,
        };

        setImages(prevImages => [...prevImages, metadata]);

        Alert.alert('Éxito', 'Imagen guardada con anotación y ubicación! 🎉');
        setCurrentImage(null);
        setAnnotation('');
        setLocation(null);
      } catch (error) {
        console.log(error);
      }
    }
  };

  const discardPicture = () => {
    setCurrentImage(null);
    setAnnotation('');
    setLocation(null);
  };

  const renderImageCard = ({ item }) => (
    <View style={styles.card}>
      <Image source={{ uri: item.uri }} style={styles.image} />
      <Text style={styles.message}>Anotación: {item.annotation}</Text>
      <Text style={styles.message}>Ubicación: {item.location}</Text>
    </View>
  );

  if (hasCameraPermission === false) {
    return <Text>No tienes acceso a la cámara</Text>;
  }

  return (
    <View style={styles.container}>
      {currentImage ? (
        <View>
          <Image source={{ uri: currentImage }} style={styles.previewImage} />
          <TextInput
            placeholder="Añadir anotación"
            value={annotation}
            onChangeText={setAnnotation}
            style={styles.annotationInput}
          />
          <TouchableOpacity onPress={() => savePicture(currentImage)} style={styles.button}>
            <Text style={styles.buttonText}>Guardar</Text>
          </TouchableOpacity>
          <TouchableOpacity onPress={discardPicture} style={styles.button}>
            <Text style={styles.buttonText}>Descartar</Text>
          </TouchableOpacity>
        </View>
      ) : (
        <>
          {images.length === 0 ? (
            <Camera
              style={styles.camera}
              type={type}
              ref={cameraRef}
              flashMode={flash}
            >
              <View style={styles.controls}>
                <TouchableOpacity
                  onPress={() => setType(
                    type === CameraType.back ? CameraType.front : CameraType.back
                  )}
                  style={styles.iconButton}
                >
                  <Text style={styles.iconText}>🔄</Text>
                </TouchableOpacity>
                <TouchableOpacity
                  onPress={() => setFlash(
                    flash === Camera.Constants.FlashMode.off
                      ? Camera.Constants.FlashMode.on
                      : Camera.Constants.FlashMode.off
                  )}
                  style={styles.iconButton}
                >
                  <Text style={styles.iconText}>
                    {flash === Camera.Constants.FlashMode.off ? '⚡' : '💡'}
                  </Text>
                </TouchableOpacity>
              </View>
            </Camera>
          ) : (
            <FlatList
              data={images}
              renderItem={renderImageCard}
              keyExtractor={(item, index) => index.toString()}
            />
          )}
          {images.length === 0 && (
            <TouchableOpacity onPress={takePicture} style={styles.button}>
              <Text style={styles.buttonText}>Tomar foto</Text>
            </TouchableOpacity>
          )}
        </>
      )}
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
  },
  camera: {
    flex: 1,
    width: '100%',
  },
  controls: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    paddingHorizontal: 30,
    marginTop: 20,
  },
  button: {
    backgroundColor: 'orange',
    padding: 10,
    borderRadius: 5,
    alignItems: 'center',
    justifyContent: 'center',
    margin: 10,
  },
  buttonText: {
    color: '#fff',
    fontSize: 18,
  },
  iconButton: {
    padding: 10,
  },
  iconText: {
    fontSize: 24,
  },
  previewImage: {
    width: 300,
    height: 300,
    borderRadius: 10,
    marginBottom: 10,
  },
  annotationInput: {
    borderColor: 'gray',
    borderWidth: 1,
    borderRadius: 5,
    padding: 10,
    width: '90%',
    marginBottom: 10,
  },
  card: {
    width: '90%',
    padding: 20,
    backgroundColor: '#fff',
    borderRadius: 10,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 10,
    marginBottom: 20,
    alignItems: 'center',
  },
  image: {
    width: '100%',
    height: 200,
    borderRadius: 10,
    marginBottom: 10,
  },
  message: {
    fontSize: 18,
    color: 'black',
    marginBottom: 10,
  },
});
