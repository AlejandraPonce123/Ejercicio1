import React, { useState, useRef, useEffect } from 'react';
import { Text, View, StyleSheet, TouchableOpacity, FlatList, TextInput, Platform, Alert } from 'react-native';
import { Camera, CameraType } from 'expo-camera';
import * as MediaLibrary from 'expo-media-library';
import * as Location from 'expo-location';

export function VideoCamera() {
  const [hasCameraPermission, setHasCameraPermission] = useState(null);
  const [hasMicrophonePermission, setHasMicrophonePermission] = useState(null);
  const [videos, setVideos] = useState([]);
  const [type, setType] = useState(CameraType.back);
  const [flash, setFlash] = useState(Camera.Constants.FlashMode.off);
  const [isRecording, setIsRecording] = useState(false);
  const [annotation, setAnnotation] = useState('');
  const [location, setLocation] = useState(null);
  const [currentVideo, setCurrentVideo] = useState(null);
  const cameraRef = useRef(null);

  useEffect(() => {
    const setupPermissions = async () => {
      const { status: cameraStatus } = await Camera.requestCameraPermissionsAsync();
      setHasCameraPermission(cameraStatus === 'granted');

      if (Platform.OS !== 'web') {
        const { status: microphoneStatus } = await Camera.requestMicrophonePermissionsAsync();
        setHasMicrophonePermission(microphoneStatus === 'granted');
      } else {
        setHasMicrophonePermission(true);
      }

      await MediaLibrary.requestPermissionsAsync();
      const locationStatus = await Location.requestForegroundPermissionsAsync();
      
      if (locationStatus.status === 'granted') {
        const location = await Location.getCurrentPositionAsync({});
        const reverseGeocode = await Location.reverseGeocodeAsync(location.coords);
        if (reverseGeocode.length > 0) {
          const city = reverseGeocode[0].city || reverseGeocode[0].region || 'Ubicación desconocida';
          setLocation(city);
        } else {
          setLocation('Ubicación desconocida');
        }
      }
    };

    setupPermissions();
  }, []);

  const startRecording = async () => {
    if (!hasCameraPermission || !hasMicrophonePermission) {
      Alert.alert('Permisos no concedidos', 'No tienes permisos para la cámara o el micrófono');
      return;
    }

    if (cameraRef.current) {
      try {
        setIsRecording(true);
        const videoData = await cameraRef.current.recordAsync();
        setCurrentVideo(videoData.uri);
      } catch (error) {
        console.log(error);
        setIsRecording(false);
      }
    }
  };

  const stopRecording = () => {
    if (cameraRef.current && isRecording) {
      cameraRef.current.stopRecording();
      setIsRecording(false);
    }
  };

  const saveVideo = async (uri) => {
    if (uri && location) {
      try {
        const asset = await MediaLibrary.createAssetAsync(uri);

        const metadata = {
          uri: asset.uri,
          annotation,
          location,
        };

        setVideos(prevVideos => [...prevVideos, metadata]);
        Alert.alert('Éxito', 'Video guardado con anotación y ubicación! 🎉');
        setCurrentVideo(null);
        setAnnotation('');
        setLocation(null);
      } catch (error) {
        console.log(error);
      }
    }
  };

  const discardVideo = () => {
    setCurrentVideo(null);
    setAnnotation('');
    setLocation(null);
  };

  const renderVideoCard = ({ item }) => (
    <View style={styles.card}>
      <Text style={styles.message}>Anotación: {item.annotation}</Text>
      <Text style={styles.message}>Ubicación: {item.location}</Text>
      <TouchableOpacity onPress={() => saveVideo(item.uri)} style={styles.button}>
        <Text style={styles.buttonText}>Guardar</Text>
      </TouchableOpacity>
    </View>
  );

  if (hasCameraPermission === false || (Platform.OS !== 'web' && hasMicrophonePermission === false)) {
    return <Text>No tienes acceso a la cámara o al micrófono</Text>;
  }

  return (
    <View style={styles.container}>
      {currentVideo ? (
        <View>
          <TextInput
            placeholder="Añadir anotación"
            value={annotation}
            onChangeText={setAnnotation}
            style={styles.annotationInput}
          />
          <TouchableOpacity onPress={() => saveVideo(currentVideo)} style={styles.button}>
            <Text style={styles.buttonText}>Guardar</Text>
          </TouchableOpacity>
          <TouchableOpacity onPress={discardVideo} style={styles.button}>
            <Text style={styles.buttonText}>Descartar</Text>
          </TouchableOpacity>
        </View>
      ) : (
        <>
          {videos.length === 0 ? (
            <Camera
              style={styles.camera}
              type={type}
              ref={cameraRef}
              flashMode={flash}
            >
              <View style={styles.controls}>
                <TouchableOpacity
                  onPress={() => setType(type === CameraType.back ? CameraType.front : CameraType.back)}
                  style={styles.iconButton}
                >
                  <Text style={styles.iconText}>🔄</Text>
                </TouchableOpacity>
                <TouchableOpacity
                  onPress={() => setFlash(flash === Camera.Constants.FlashMode.off ? Camera.Constants.FlashMode.on : Camera.Constants.FlashMode.off)}
                  style={styles.iconButton}
                >
                  <Text style={styles.iconText}>{flash === Camera.Constants.FlashMode.off ? '⚡' : '💡'}</Text>
                </TouchableOpacity>
              </View>
            </Camera>
          ) : (
            <FlatList
              data={videos}
              renderItem={renderVideoCard}
              keyExtractor={(item, index) => index.toString()}
            />
          )}

          {videos.length === 0 && (
            <>
              {isRecording ? (
                <TouchableOpacity onPress={stopRecording} style={[styles.button, { backgroundColor: 'red' }]}>
                  <Text style={styles.buttonText}>Detener grabación</Text>
                </TouchableOpacity>
              ) : (
                <TouchableOpacity onPress={startRecording} style={styles.button}>
                  <Text style={styles.buttonText}>Iniciar grabación</Text>
                </TouchableOpacity>
              )}
            </>
          )}
        </>
      )}
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
  },
  camera: {
    flex: 1,
    width: '100%',
  },
  button: {
    backgroundColor: 'orange',
    padding: 10,
    borderRadius: 5,
    alignItems: 'center',
    justifyContent: 'center',
    margin: 10,
  },
  buttonText: {
    color: '#fff',
    fontSize: 18,
  },
  iconButton: {
    padding: 10,
  },
  iconText: {
    fontSize: 24,
  },
  controls: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    paddingHorizontal: 30,
    marginTop: 20,
  },
  annotationInput: {
    borderColor: 'gray',
    borderWidth: 1,
    borderRadius: 5,
    padding: 10,
    width: '90%',
    marginBottom: 10,
  },
  card: {
    width: '90%',
    padding: 20,
    backgroundColor: '#fff',
    borderRadius: 10,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 10,
    marginBottom: 20,
    alignItems: 'center',
  },
  message: {
    fontSize: 18,
    color: 'black',
    marginBottom: 10,
  },
});
