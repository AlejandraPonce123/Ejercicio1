import { Text, View, StyleSheet, TouchableOpacity } from 'react-native';
import Icon from "react-native-vector-icons/Ionicons";



export function MediaButton({ label = 'none', icon= 'film', onPress}) {

  return (
    <TouchableOpacity onPress={onPress} style={styles.touchable}>
      <View style={styles.button_default}>
        <Icon name={icon} size={40} color="white" />
        <Text style={styles.text}>{label}</Text>
      </View>
    </TouchableOpacity>
  );
}

const styles = StyleSheet.create({
  button_default: {
    flexDirection: 'column',
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: 'dodgerblue',
    height:120,
    width:120,
    margin:20
  },
  text: {
    fontSize: 20,
    fontWeight: 'bold',
    color: 'white'
  },
  touchable:{
    flex:1,
    alignItems: 'center'
  }
});
